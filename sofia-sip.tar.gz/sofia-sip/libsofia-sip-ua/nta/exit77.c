int main(int argc, char *argv[])
{
  return 77; /* exit code indicating make check that test has been SKIPped */
}
